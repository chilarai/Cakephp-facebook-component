<?php
/*
 * Name : tests_controller.php
 * Cakephp Controller to integrate with Facebook
 * Copyright (C) 2011,  Chilarai Mushahary.
 * Write to me at : chilly5476@gmail.com 
 * http://www.wreken.com/facebook-component
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
*/
class TestsController extends AppController {
	var $name = 'Tests';
	var $components = array('Facebook');

	function index(){
	}
	
// =========================
// GET THE APP ACCESS TOKEN
// ==========================

	function getaccesstoken() {
		$accessToken = $this->Facebook->getAccessToken();
		$this->set('accessToken',$accessToken);
	}

// ======================
// GET YOUR FRIENDS LIST
// ======================

	function getfriends() {
		$getFriends = $this->Facebook->getFriends() ;
		
		
		if($getFriends['status']== 0) {
			$this->redirect($getFriends['object']);
		}
		else {
			//print_r($getFriends['object']);
			debug(json_decode(file_get_contents($getFriends['object'])),true);
			$this->set('friends',$getFriends['object']);
		}
	}

// =========================================
// GET YOUR DETAILS
// like facebook id, username, location, etc
// ==========================================

	function getmydetails() {
		$getMyDetails = $this->Facebook->getMyDetails() ;
		if($getMyDetails['status']== 0) {
			$this->redirect($getMyDetails['object']);
		}
		else {
			debug(json_decode(file_get_contents($getMyDetails['object'])),true);
		}
	}

// ========================
// GET PROFILE PICTURE
// ========================

	function getprofilepicture($id=null) {
	
		// in this example id = my id
		// in case, you do not pass an id, you will get your own profile picture

		$getProfilePicture = $this->Facebook->getProfilePicture() ;
		
		
		if($getProfilePicture['status']== 0) {
			echo '<script>top.location="'.$getProfilePicture['object'].'";</script>';
		}
		else {
			$this->set('image',$getProfilePicture['object']);
		}
	}

// =================
// GET APP REQUESTS
// =================

	function getapprequests() {
		$getAppRequests = $this->Facebook->getAppRequests() ;
		if($getAppRequests['status']== 0) {
			echo '<script>top.location="'.$getAppRequests['object'].'";</script>';
		}
		else {
			debug(json_decode(file_get_contents($getAppRequests['object'])),true);
		}
	}

// ================
// GET YOUR ALBUMS
// =================

	function getalbums() {
		$getAlbums = $this->Facebook->getAlbums() ;
		if($getAlbums['status']== 0) {
			echo '<script>top.location="'.$getAlbums['object'].'";</script>';
		}
		else {
			debug(json_decode(file_get_contents($getAlbums['object'])),true);
		}
	}

// ===========================
// POST ON WALL FROM THE APP
// ===========================

	function postwall() {
	
	 // you have to set these variables according to the post that you want to appear in the fb wall.
	 // subheading and picturelink can be blank. to leave them blank, just leave two single quotes in their places
	 // eg. $this->Facebook->postWall('heading','','applink','appname','description','');
	
		$heading = 'Main Heading';
		$subheading = 'Caption'; // can be blank
		$appLink = 'Your application server address';
		$appName = 'Name of your app';
		$description = 'Message to appear in the post'; 
		$pictureLink = 'Image link if any'; //can be blank

	    $postWall = $this->Facebook->postWall($heading,$subheading,$appLink,$appName,$description,$pictureLink) ;
	    
		//$postWall = $this->Facebook->postWall($heading,$subheading,$appLink,$appName,$description,$pictureLink) ;
		if($postWall['status']== 0) {
			echo '<script>top.location="'.$postWall['object'].'";</script>';
		}
		else {
			$this->Session->setFlash("Posted on your wall");
		}
	}

// ==================================
// SEND APP REQUESTS TO YOUR FRIENDS
// ==================================

	function apprequest() {

	// you can set the variables as required
	// `message` variable is the message you want to be the heading of the request page.
	// `returnUrl` variable has to point somewhere to your app which will receive get parameters like app request id 

		$message = 'Your Message';
		$returnUrl = 'Your return url'; 
		
		$appRequest = $this->Facebook->appRequest($message,$returnUrl) ;
		if($appRequest['status']== 0) {
			echo '<script>top.location="'.$appRequest['object'].'";</script>';
		}
		else {
			echo("<script> top.location.href='" . $appRequest['object'] . "'</script>"); // app requests
		}
	}
}
?>
