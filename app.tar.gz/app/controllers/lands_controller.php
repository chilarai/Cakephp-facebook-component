<?php
/*
 * Name : lands_controller.php
 * Cakephp Controller to integrate with Facebook
 * Copyright (C) 2011,  Chilarai Mushahary.
 * Write to me at : chilly5476@gmail.com 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
*/
class LandsController extends AppController {
	var $name = 'Lands';
	var $uses = null;
	var $components = array('Facebook');
	
// =================================================================
// DEMO TO DELETE APP REQUEST AND PERFORM ON THE REQUEST PARAMETERS 
// =================================================================

	function index() {
	/*
	 * This controller is the sample controller to see the request parameters when accepting an app request
 	 * This demonstrates how a requests have to be handled
 	 * To implement this in your actual app, you need to put this code in your canvas url
	 * so that when the users land in your app, the needed operations are performed and the existing request is deleted
	 */
		if(!empty($_REQUEST['request_ids'])) {

			$accessToken = $this->Facebook->getAccessToken();
			
			// Get the request details using Graph API
			$request = $_REQUEST['request_ids'];
			$requestContent = json_decode(file_get_contents("https://graph.facebook.com/".$request."?access_token=$accessToken"), TRUE);
			
			$this->set('requestContent',$requestContent);
			$this->set('RequestIds',$request);
			
			// delete the request once you operated on it
			file_get_contents("https://graph.facebook.com/$request?access_token=$accessToken&method=delete");
		}
	}
}
?>
