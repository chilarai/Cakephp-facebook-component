<?php
/*
 * Name : cores_controller.php
 * Cakephp Component to integrate with Facebook
 * Copyright (C) 2011,  Chilarai Mushahary.
 * Write to me at : chilly5476@gmail.com 
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
*/
class CoresController extends AppController {
	var $name = 'Cores';
	var $uses = Null;
	
	function index() {
		$this->layout='install';
		if(!empty($this->data)) {
			$appId 			= $this->data['Core']['app_id'];
			$appKey			= $this->data['Core']['app_key'];
			$appSecret 		= $this->data['Core']['app_secret'];
			$appCanvas 		= $this->data['Core']['app_canvas'];
			$appUri			= $this->data['Core']['app_uri'];

			
			if(Configure::read('AppId') == null) {
				
				$fileContentAdd = 
				"<?php
						Configure::write('AppId','$appId'); //--> from facebook app page

						Configure::write('AppKey','$appKey');	//--> from your facebook app page

						Configure::write('AppSecret','$appSecret');	//--> from your facebook app page

						Configure::write('AppUri','$appUri');	//--> your app folder (eg localhost/cake)

						Configure::write('CanvasPage','$appCanvas'); //--> your canvas page (from facebook. remember the trailing '/')
				?>";
				
				// write into the config/core.php file
				
				$fileHandle = fopen('../config/core.php','a');
				fwrite($fileHandle,$fileContentAdd);
				fclose($fileHandle);
				
				
				$this->redirect('/homes/index');
				
			}
			
		}
	}
}
?>
