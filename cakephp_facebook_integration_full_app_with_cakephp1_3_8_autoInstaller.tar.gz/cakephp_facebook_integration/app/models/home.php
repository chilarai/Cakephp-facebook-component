<?php
class Home extends AppModel {
	var $name = 'Home';
}
?>
